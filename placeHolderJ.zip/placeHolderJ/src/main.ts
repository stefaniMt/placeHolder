import { fetchPostCount, fetchCommentCount, fetchAlbumCount, fetchPhotoCount, fetchTodoCount, fetchUserCount } from './utils/countRecords';
import { getPostComments, getUserPosts } from './utils/postOperations';
import { Post } from './interface/post.interface';
import { comment } from './interface/commentsinterface';
import * as readline from 'readline';

const rl = readline.createInterface({
  input: process.stdin,
  output: process.stdout
});

//funcion para preguntas
function askQuestion(query: string): Promise<string> {
  return new Promise(resolve => rl.question(query, resolve));
}

// Menu principal
async function showMenu() {
  let exit = false;
  while (!exit) {
    console.log(`
      1. Obtener cantidad de registros
      2. Mostrar comentarios de un post específico
      3. Mostrar posts de un usuario
      4. Salir
    `);
    const choice = await askQuestion("ᯓ★Seleccione una opción: ");

    switch (choice) {
      case '1':
        await showRecordCounts();
        break;
      case '2':
        await showPostComments();
        break;
      case '3':
        await showUserPosts();
        break;
      case '4':
        exit = true;
        console.log("⭑ Saliendo๋࣭ ⭑⚝๋࣭ ⭑");
        break;
      default:
        console.log("ᯓ★Opción no válida. Intente de nuevo.");
    }
  }
  rl.close();
}

//cantidades de registros de cada endpoint
async function showRecordCounts() {
  console.log("ᯓ★Obteniendo cantidades de cada endpoint...");
  const [postCount, commentCount, albumCount, photoCount, todoCount, userCount] = await Promise.all([
    fetchPostCount(),
    fetchCommentCount(),
    fetchAlbumCount(),
    fetchPhotoCount(),
    fetchTodoCount(),
    fetchUserCount()
  ]);
  console.log(`Posts: ${postCount}`);
  console.log(`Comments: ${commentCount}`);
  console.log(`Albums: ${albumCount}`);
  console.log(`Photos: ${photoCount}`);
  console.log(`Todos: ${todoCount}`);
  console.log(`Users: ${userCount}`);
}

//mostrar comentarios de un post específico
async function showPostComments() {
  const postId = parseInt(await askQuestion("ᯓ★Ingrese el ID del post para ver comentarios: "), 10);
  if (isNaN(postId)) {
    console.log("ID de post no valido");
    return;
  }
  const comment: Comment[] = await getPostComments(postId);
  console.log(`Comentarios para el post ${postId}:`, comment);
}

//mostrar posts de un usuario específico
async function showUserPosts() {
  const userId = parseInt(await askQuestion("Ingrese el ID del usuario para ver sus posts: "), 10);
  if (isNaN(userId)) {
    console.log("ID de usuario no válido.");
    return;
  }
  const posts: Post[] = await getUserPosts(userId);
  console.log(`Posts para el usuario ${userId}:`, posts);
}

// para ejcutar el menu
showMenu();
