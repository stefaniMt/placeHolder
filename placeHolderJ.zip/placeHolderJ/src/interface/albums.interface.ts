
export interface album {
  userId: number
  id: number
  title: string
}
