import { Post } from "../interface/post.interface";
import { comment } from "../interface/commentsinterface";

export async function getPostComments(postId: number): Promise<Comment[]> {
    const response = await fetch(`https://jsonplaceholder.typicode.com/posts/${postId}/comments`);
    const comments: Comment[] = await response.json();
    return comments;
  }

export async function getUserPosts(userId: number): Promise<Post[]> {
  const response = await fetch(`https://jsonplaceholder.typicode.com/users/${userId}/posts`);
  const posts: Post[] = await response.json();
  return posts;
}
