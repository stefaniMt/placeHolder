import { Post } from '../interface/post.interface';
import { comment } from '../interface/commentsinterface';
import { album } from '../interface/albums.interface';
import { photos } from '../interface/photos.interface';
import { todo } from 'node:test';
import { User } from '../interface/user.interface';
import { todos } from '../interface/todos.interface';

export async function fetchPostCount(): Promise<number> {
  const response = await fetch('https://jsonplaceholder.typicode.com/posts');
  const posts: Post[] = await response.json();
  return posts.length;
}

export async function fetchCommentCount(): Promise<number> {
  const response = await fetch('https://jsonplaceholder.typicode.com/comments');
  const comments: Comment[] = await response.json();
  return comments.length;
}

export async function fetchAlbumCount(): Promise<number> {
  const response = await fetch('https://jsonplaceholder.typicode.com/albums');
  const albums: album[] = await response.json();
  return albums.length;
}

export async function fetchPhotoCount(): Promise<number> {
  const response = await fetch('https://jsonplaceholder.typicode.com/photos');
  const photos: photos[] = await response.json();
  return photos.length;
}

export async function fetchTodoCount(): Promise<number> {
  const response = await fetch('https://jsonplaceholder.typicode.com/todos');
  const todos: todos[] = await response.json();
  return todos.length;
}

export async function fetchUserCount(): Promise<number> {
  const response = await fetch('https://jsonplaceholder.typicode.com/users');
  const users: User[] = await response.json();
  return users.length;
}
